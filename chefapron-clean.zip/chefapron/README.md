# Chef Apron — chefapron.ng

Website for Chef Store: chef aprons, culinary items and hands-on training.

## Stack
TanStack Start, React 19, Tailwind CSS 4, Supabase.

## Development
```sh
npm install
npm run dev      # http://localhost:8080
npm run build
```

## Environment variables
Copy `.env.example` to `.env` and fill in the Supabase values.

## Media
Images and videos live in `public/media/`. Pointers to them are in `src/assets/*.asset.json`.
